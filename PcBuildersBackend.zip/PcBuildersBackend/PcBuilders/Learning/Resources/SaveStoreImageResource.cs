﻿namespace LearningCenter.API.Learning.Resources;

public class SaveStoreImageResource
{
    public string Enconded64Image { get; set; }
    public int StoreId { get; set; }
}