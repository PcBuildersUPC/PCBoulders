﻿namespace LearningCenter.API.Learning.Resources;

public class SavePurchaseResource
{
    public string Code { get; set; }
    public int UserId { get; set; }
}