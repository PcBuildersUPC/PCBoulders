﻿namespace LearningCenter.API.Learning.Resources;

public class ProductToPurchaseResource
{
    public int PurchaseId { get; set; }
    public int ProductId { get; set; }
}