﻿namespace LearningCenter.API.Learning.Resources;

public class ProductToSaleResource
{
    public int SaleId { get; set; }
    public int ProductId { get; set; }
}