﻿namespace LearningCenter.API.Learning.Resources;

public class SaveSaleResource
{
    public string Code { get; set; }
    public int PurchaserId { get; set; }
    public int StoreId { get; set; }
}