using System;
using TechTalk.SpecFlow;

namespace LearningCenter.API.Test.Hooks
{
    [Binding]
    public class Hooks
    {
    }
}